This is a small wrapper around https://github.com/facebooknuclide/nuclide-prebuilt-libs/tree/master/fuzzy-native.
